/*
使用了单例模式，避免了全局变量，全局函数被覆盖。
*/
var index = {
  innit: function() {
    var baidu = this;
    baidu.render();
    baidu.bind();
  },
  render: function() {
    var baidu = this;
    var spans = document.getElementsByClassName('navlist');
    var spanContain = document.getElementsByClassName('type-box');
    baidu.contain = spanContain;
    baidu.btn = spans;
  },
  bind: function() {
    var baidu = this;
    for (var i = 0; i < baidu.btn.length; i++) {
      baidu.btn[i].onclick = function() {
        for (var i = 0; i < baidu.btn.length; i++) {
          if (this == baidu.btn[i]) {
            baidu.contain[i].style.display = 'block';
          } else {
            baidu.contain[i].style.display = 'none';
          }
        }
      }
    }
  }
};
window.onload = function() {
  index.innit();
}